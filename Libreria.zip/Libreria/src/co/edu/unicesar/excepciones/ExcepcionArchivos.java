package co.edu.unicesar.excepciones;

import java.io.IOException;

public class ExcepcionArchivos extends IOException {

    public ExcepcionArchivos(String string) {
        super(string);
    }

}
