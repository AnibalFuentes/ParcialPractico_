package co.edu.unicesar.modelo;

import java.io.Serializable;

public class AudioLibro extends Publicacion implements Serializable {

    private double duracion;
    private double peso;
    private String formato;

    public AudioLibro(String idbn) {
        super(idbn);
    }

    public AudioLibro() {
    }

    public AudioLibro(double duracion, double peso, String formato, String idbn, String titulo, String autor, int anio, double costo) {
        super(idbn, titulo, autor, anio, costo);
        this.duracion = duracion;
        this.peso = peso;
        this.formato = formato;
    }

    public double getDuracion() {
        return duracion;
    }

    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    @Override
    public String toString() {
        return "AudioLibro{" + super.toString() + ", duracion=" + duracion + ", peso=" + peso + ", formato=" + formato + '}';
    }

    @Override
    public String obtenerDatosString() {
        return this.isbn + ";" + this.titulo + ";" + this.autor + ";" + this.anio + ";" + this.costo + ";" + this.duracion + ";" + this.peso + ";" + this.formato;
    }

}
