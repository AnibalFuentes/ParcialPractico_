package co.edu.unicesar.modelo;

import java.io.Serializable;

public class Libro extends Publicacion implements Serializable {

    private int nPaginas;
    private int nEdicion;

    public Libro() {
    }

    public Libro(String isbn) {
        super(isbn);
    }

    public Libro(int nPaginas, int nEdicion, String isbn, String titulo, String autor, int anio, double costo) {
        super(isbn, titulo, autor, anio, costo);
        this.nPaginas = nPaginas;
        this.nEdicion = nEdicion;
    }

    public int getnPaginas() {
        return nPaginas;
    }

    public int getnEdicion() {
        return nEdicion;
    }

    public void setnPaginas(int nPaginas) {
        this.nPaginas = nPaginas;
    }

    public void setnEdicion(int nEdicion) {
        this.nEdicion = nEdicion;
    }

    @Override
    public String obtenerDatosString() {
        return this.isbn + ";" + this.titulo + ";" + this.autor + ";" + this.anio + ";" + this.costo + ";" + this.nPaginas + ";" + this.nEdicion;
    }

}
