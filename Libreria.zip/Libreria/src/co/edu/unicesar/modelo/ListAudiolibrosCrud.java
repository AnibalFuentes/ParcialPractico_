package co.edu.unicesar.modelo;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.persistencia.ImpArchivoTextoAudiolibro;
import co.edu.unicesar.persistencia.IntAudioLibroCrud;
import java.util.List;


public class ListAudiolibrosCrud implements IntAudioLibroCrud {

    //ARCHIVO DE TEXTO
    private IntAudioLibroCrud baseDatos = new ImpArchivoTextoAudiolibro();
    //ARCHIVO DE OBJETO
    //private IAudioLibroCrud baseDatos = new ImpArchivoObjetoAudioLibro();

    @Override
    public void registrar(AudioLibro l) throws ExcepcionArchivos {
        this.baseDatos.registrar(l);
    }

    @Override
    public List<AudioLibro> leer() throws ExcepcionArchivos {
        return this.baseDatos.leer();
    }

    @Override
    public AudioLibro buscar(AudioLibro l) throws ExcepcionArchivos {
        return this.baseDatos.buscar(l);
    }

    @Override
    public AudioLibro eliminar(AudioLibro l) throws ExcepcionArchivos {
        return this.baseDatos.eliminar(l);
    }

    @Override
    public List<AudioLibro> filtrar(int isbn) throws ExcepcionArchivos {
        return this.baseDatos.filtrar(isbn);
    }

}
