package co.edu.unicesar.modelo;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.persistencia.ILibroCrud;
import co.edu.unicesar.persistencia.ImpArchivoObjetoLibro;
import java.util.List;


public class ListLibrosCrud implements ILibroCrud {

   
    private ILibroCrud baseDatos = new ImpArchivoObjetoLibro();

    @Override
    public void registrar(Libro l) throws ExcepcionArchivos {
        this.baseDatos.registrar(l);
    }

    @Override
    public List<Libro> leer() throws ExcepcionArchivos {
        return this.baseDatos.leer();
    }

    @Override
    public Libro buscar(Libro l) throws ExcepcionArchivos {
        return this.baseDatos.buscar(l);
    }

    @Override
    public Libro eliminar(Libro l) throws ExcepcionArchivos {
        return this.baseDatos.eliminar(l);
    }

    @Override
    public List<Libro> filtrar(int isbn) throws ExcepcionArchivos {
        return this.baseDatos.filtrar(isbn);
    }

}
