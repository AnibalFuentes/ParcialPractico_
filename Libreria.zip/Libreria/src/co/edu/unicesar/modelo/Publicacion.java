package co.edu.unicesar.modelo;

import java.io.Serializable;

public abstract class Publicacion implements Serializable {

    //ATRIBUTOS
    protected String isbn;
    protected String titulo;
    protected String autor;
    protected int anio;
    protected double costo;

    public Publicacion() {
    }

    public Publicacion(String isbn) {
        this.isbn = isbn;
    }
    
    public Publicacion(String isbn, String titulo, String autor, int anio, double costo) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.anio = anio;
        this.costo = costo;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAnio() {
        return anio;
    }

    public double getCosto() {
        return costo;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }
    
    public abstract String obtenerDatosString();
}
