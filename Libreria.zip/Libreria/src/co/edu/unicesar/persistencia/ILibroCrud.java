package co.edu.unicesar.persistencia;

import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.Libro;
import java.util.List;

public interface ILibroCrud {

    void registrar(Libro l) throws ExcepcionArchivos;

    List<Libro> leer() throws ExcepcionArchivos;

    Libro buscar(Libro l) throws ExcepcionArchivos;

    Libro eliminar(Libro l) throws ExcepcionArchivos;

    List<Libro> filtrar(int isbn) throws ExcepcionArchivos;

}
