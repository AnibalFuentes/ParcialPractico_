package co.edu.unicesar.persistencia;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.AudioLibro;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class ImpArchivoObjetoAudioLibro implements IntAudioLibroCrud {

    private File archivo;
    private FileInputStream modoLectura;
    private FileOutputStream modoEscritura;

    public ImpArchivoObjetoAudioLibro() {
        this("AudioLibro.obj");
    }

    public ImpArchivoObjetoAudioLibro(String path) {
        this.archivo = new File(path);
    }

    private void guardar(List<AudioLibro> lista) throws ExcepcionArchivos {
        ObjectOutputStream oos = null;
        try {
            this.modoEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.modoEscritura);
            oos.writeObject(lista);
            oos.close();

        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("El Archivo de escritura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivos("No tiene permiso de escritura sobre el archivo");
        } catch (IOException e) {
            throw new ExcepcionArchivos("Error al escribir en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivos("Los datos de la lista son null");
        }

    }

    private List<AudioLibro> cargarArchivo() throws ExcepcionArchivos {
        ObjectInputStream ois = null;
        if (!this.archivo.exists()) {
            return new ArrayList<AudioLibro>();
        }
        try {
            this.modoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.modoLectura);
            List<AudioLibro> lista = (List<AudioLibro>) ois.readObject();
            ois.close();
            return lista;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("El Archivo de lectura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivos("No tiene permiso de lectura sobre el archivo");
        } catch (StreamCorruptedException e) {
            throw new ExcepcionArchivos("Error con los datos de flujo de cierre del objeto");
        } catch (IOException e) {
            throw new ExcepcionArchivos("Error al leer en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivos("El archivo a leer es null");
        } catch (ClassNotFoundException e) {
            throw new ExcepcionArchivos("No existe la claase definida para el objeto leido");
        }

    }

    @Override
    public void registrar(AudioLibro a) throws ExcepcionArchivos {
        List<AudioLibro> lista = this.cargarArchivo();
        lista.add(a);
        this.guardar(lista);
    }

    @Override
    public List<AudioLibro> leer() throws ExcepcionArchivos {
        return this.cargarArchivo();
    }

    @Override
    public AudioLibro buscar(AudioLibro a) throws ExcepcionArchivos {
        List<AudioLibro> lista = this.cargarArchivo();
        AudioLibro buscado = null;
        for (AudioLibro i : lista) {
            if (i.getIsbn().equals(a.getIsbn())) {
                buscado = i;
                break;
            }
        }
        return buscado;
    }

    @Override
    public AudioLibro eliminar(AudioLibro a) throws ExcepcionArchivos {
        List<AudioLibro> lista = this.cargarArchivo();
        AudioLibro eliminar = null;
        Iterator<AudioLibro> i = lista.iterator();
        while (i.hasNext()) {
            AudioLibro aux = i.next();
            if (aux.getIsbn().equals(a.getIsbn())) {
                eliminar = aux;
                i.remove();
            }
        }
        this.guardar(lista);
        return eliminar;
    }

    @Override
    public List<AudioLibro> filtrar(int isbn) throws ExcepcionArchivos {
        List<AudioLibro> lista = this.cargarArchivo();
        List<AudioLibro> listaFiltrada = new ArrayList();
        for (AudioLibro audiolibro : lista) {
            String serialLista = audiolibro.getIsbn();
            String serialFiltrada = String.valueOf(isbn);
            if (serialLista.contains(serialFiltrada)) {
                listaFiltrada.add(audiolibro);
            }
        }
        return listaFiltrada;
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileInputStream getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(FileInputStream modoLectura) {
        this.modoLectura = modoLectura;
    }

    public FileOutputStream getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileOutputStream modoEscritura) {
        this.modoEscritura = modoEscritura;
    }
}
