package co.edu.unicesar.persistencia;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.Libro;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class ImpArchivoObjetoLibro implements ILibroCrud {

    private File archivo;
    private FileInputStream modoLectura;
    private FileOutputStream modoEscritura;

    public ImpArchivoObjetoLibro() {
        this("Libros.obj");
    }

    public ImpArchivoObjetoLibro(String path) {
        this.archivo = new File(path);
    }

    private void guardar(List<Libro> lista) throws ExcepcionArchivos {
        ObjectOutputStream oos = null;
        try {
            this.modoEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.modoEscritura);
            oos.writeObject(lista);
            oos.close();

        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("El Archivo de escritura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivos("No tiene permiso de escritura sobre el archivo");
        } catch (IOException e) {
            throw new ExcepcionArchivos("Error al escribir en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivos("Los datos de la lista son null");
        }

    }

    private List<Libro> cargarArchivo() throws ExcepcionArchivos {
        ObjectInputStream ois = null;
        if (!this.archivo.exists()) {
            return new ArrayList<Libro>();
        }
        try {
            this.modoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.modoLectura);
            List<Libro> lista = (List<Libro>) ois.readObject();
            ois.close();
            return lista;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("El Archivo de lectura no existe, o no se puede abrir");
        } catch (SecurityException e) {
            throw new ExcepcionArchivos("No tiene permiso de lectura sobre el archivo");
        } catch (StreamCorruptedException e) {
            throw new ExcepcionArchivos("Error con los datos de flujo de cierre del objeto");
        } catch (IOException e) {
            throw new ExcepcionArchivos("Error al leer en el archivo");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivos("El archivo a leer es null");
        } catch (ClassNotFoundException e) {
            throw new ExcepcionArchivos("No existe la claase definida para el objeto leido");
        }

    }

    @Override
    public void registrar(Libro l) throws ExcepcionArchivos {
        List<Libro> lista = this.cargarArchivo();
        lista.add(l);
        this.guardar(lista);
    }

    @Override
    public List<Libro> leer() throws ExcepcionArchivos {
        return this.cargarArchivo();
    }

    @Override
    public Libro buscar(Libro l) throws ExcepcionArchivos {
        List<Libro> lista = this.cargarArchivo();
        Libro buscado = null;
        for (Libro i : lista) {
            if (i.getIsbn().equals(l.getIsbn())) {
                buscado = i;
                break;
            }
        }
        return buscado;
    }

    @Override
    public Libro eliminar(Libro l) throws ExcepcionArchivos {
        List<Libro> lista = this.cargarArchivo();
        Libro eliminar = null;
        Iterator<Libro> i = lista.iterator();
        while (i.hasNext()) {
            Libro aux = i.next();
            if (aux.getIsbn().equals(l.getIsbn())) {
                eliminar = aux;
                i.remove();
            }
        }
        this.guardar(lista);

        return eliminar;

    }

    @Override
    public List<Libro> filtrar(int isbn) throws ExcepcionArchivos {
        List<Libro> lista = this.cargarArchivo();
        List<Libro> listaFiltrada = new ArrayList();
        for (Libro libro : lista) {
            String serialLista = libro.getIsbn();
            String serialFiltrada = String.valueOf(isbn);
            if (serialLista.contains(serialFiltrada)) {
                listaFiltrada.add(libro);
            }
        }
        return listaFiltrada;
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileInputStream getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(FileInputStream modoLectura) {
        this.modoLectura = modoLectura;
    }

    public FileOutputStream getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileOutputStream modoEscritura) {
        this.modoEscritura = modoEscritura;
    }
}
