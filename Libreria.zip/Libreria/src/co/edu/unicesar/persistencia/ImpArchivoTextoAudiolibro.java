package co.edu.unicesar.persistencia;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.AudioLibro;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class ImpArchivoTextoAudiolibro implements IntAudioLibroCrud {

    private File archivo;
    private FileWriter modoEscritura;
    private Scanner modoLectura;

    public ImpArchivoTextoAudiolibro() {
        this("Audiolibros.inv");
    }

    public ImpArchivoTextoAudiolibro(String path) {
        this.archivo = new File(path);
    }

    private AudioLibro cargar(String data[]) {
        String isbn = data[0];
        String titulo = data[1];
        String autor = data[2];
        int anio = Integer.valueOf(data[3]);
        double costo = Double.valueOf(data[4]);
        double duracion = Double.valueOf(data[5]);
        double peso = Double.valueOf(data[6]);
        String formato = data[7];
        return new AudioLibro(duracion, peso, formato, isbn, titulo, autor, anio, costo) {
        };
    }

    private void renombrarArchivo(File tmp) throws IOException {
        if (!tmp.exists()) {
            tmp.createNewFile();
        }
        if (!this.archivo.delete()) {
            throw new IOException("Error al eliminar el archivo principal");
        }
        if (!tmp.renameTo(this.archivo)) {
            throw new IOException("Error al renombrar el archivo tmp");
        }

    }

    @Override
    public void registrar(AudioLibro a) throws ExcepcionArchivos {
        PrintWriter pw = null;
        try {
            this.modoEscritura = new FileWriter(this.archivo, true);
            pw = new PrintWriter(this.modoEscritura);
            pw.println(a.obtenerDatosString());
        } catch (IOException e) {
            throw new ExcepcionArchivos("Error al abrir o crear archivo en modo escritura");
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }

    @Override
    public List<AudioLibro> leer() throws ExcepcionArchivos {
        List<AudioLibro> lista;
        try {
            this.modoLectura = new Scanner(this.archivo);
            lista = new ArrayList();
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                AudioLibro a = this.cargar(data);
                lista.add(a);
            }
            return lista;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("Error al leer archivo en modo lectura");
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }

    }

    @Override
    public AudioLibro buscar(AudioLibro a) throws ExcepcionArchivos {
        AudioLibro buscado = null;
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                buscado = this.cargar(data);
                if (buscado.getIsbn() == null ? a.getIsbn() == null : buscado.getIsbn().equals(a.getIsbn())) {
                    return buscado;
                }
            }
            return null;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("Error al buscar archivo en modo lectura");
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public AudioLibro eliminar(AudioLibro a) throws ExcepcionArchivos {
        AudioLibro eliminado = null;
        ImpArchivoTextoAudiolibro archivoTemporal = new ImpArchivoTextoAudiolibro("Libros.tmp");
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                AudioLibro aux = this.cargar(data);
                if (aux.getIsbn().equals(a.getIsbn())) {
                    eliminado = aux;
                } else {
                    archivoTemporal.registrar(aux);
                }
            }
            this.modoLectura.close();
            this.renombrarArchivo(archivoTemporal.archivo);
            return eliminado;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("Error al buscar archivo en modo lectura");
        } catch (IOException e) {
            throw new ExcepcionArchivos(e.getMessage());
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public List<AudioLibro> filtrar(int isbn) throws ExcepcionArchivos {
        List<AudioLibro> lista = this.leer();
        List<AudioLibro> listaFiltrada = new ArrayList();
        for (AudioLibro audiolibro : lista) {
            String isbnLista = String.valueOf(audiolibro.getIsbn());
            String isbnFiltrado = String.valueOf(isbn);
            if (isbnLista.contains(isbnFiltrado)) {
                listaFiltrada.add(audiolibro);
            }
        }
        return listaFiltrada;
    }

    public File getArchivo() {
        return archivo;
    }

    public FileWriter getModoEscritura() {
        return modoEscritura;
    }

    public Scanner getModoLectura() {
        return modoLectura;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public void setModoEscritura(FileWriter modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    public void setModoLectura(Scanner modoLectura) {
        this.modoLectura = modoLectura;
    }
}
