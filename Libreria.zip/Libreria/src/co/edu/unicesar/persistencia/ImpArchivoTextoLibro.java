package co.edu.unicesar.persistencia;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.Libro;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class ImpArchivoTextoLibro implements ILibroCrud {

    File archivo;
    private FileWriter modoEscritura;
    private Scanner modoLectura;

    public ImpArchivoTextoLibro() {
        this("Libros.inv");
    }

    public ImpArchivoTextoLibro(String path) {
        this.archivo = new File(path);
    }

    private Libro cargar(String data[]) {
        String isbn = data[0];
        String titulo = data[1];
        String autor = data[2];
        int anio = Integer.valueOf(data[3]);
        double costo = Double.valueOf(data[4]);
        int nPaginas = Integer.valueOf(data[5]);
        int edicion = Integer.valueOf(data[6]);
        return new Libro(nPaginas, edicion, isbn, titulo, autor, anio, costo) {
        };
    }

    private void renombrarArchivo(File tmp) throws IOException {
        if (!tmp.exists()) {
            tmp.createNewFile();
        }
        if (!this.archivo.delete()) {
            throw new IOException("Error al eliminar el archivo principal");
        }
        if (!tmp.renameTo(this.archivo)) {
            throw new IOException("Error al renombrar el archivo tmp");
        }

    }

    @Override
    public void registrar(Libro l) throws ExcepcionArchivos {
        PrintWriter pw = null;
        try {
            this.modoEscritura = new FileWriter(this.archivo, true);
            pw = new PrintWriter(this.modoEscritura);
            pw.println(l.obtenerDatosString());
        } catch (IOException e) {
            throw new ExcepcionArchivos("Error al abrir o crear archivo en modo escritura");
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }

    @Override
    public List<Libro> leer() throws ExcepcionArchivos {
        List<Libro> lista;
        try {
            this.modoLectura = new Scanner(this.archivo);
            lista = new ArrayList();
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                Libro l = this.cargar(data);
                lista.add(l);
            }
            return lista;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("Error al leer archivo en modo lectura");
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public Libro buscar(Libro l) throws ExcepcionArchivos {
        Libro buscado = null;
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                buscado = this.cargar(data);
                if (buscado.getIsbn() == null ? l.getIsbn() == null : buscado.getIsbn().equals(l.getIsbn())) {
                    return buscado;
                }
            }
            return null;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("Error al buscar archivo en modo lectura");
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public Libro eliminar(Libro l) throws ExcepcionArchivos {
        Libro eliminado = null;
        ImpArchivoTextoLibro archivoTemporal = new ImpArchivoTextoLibro("Libros.tmp");
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String[] data = this.modoLectura.nextLine().split(";");
                Libro aux = this.cargar(data);
                if (aux.getIsbn().equals(l.getIsbn())) {
                    eliminado = aux;
                } else {
                    archivoTemporal.registrar(aux);
                }
            }
            this.modoLectura.close();
            this.renombrarArchivo(archivoTemporal.archivo);
            return eliminado;
        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivos("Error al buscar archivo en modo lectura");
        } catch (IOException e) {
            throw new ExcepcionArchivos(e.getMessage());
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public List<Libro> filtrar(int isbn) throws ExcepcionArchivos {
        List<Libro> lista = this.leer();
        List<Libro> listaFiltrada = new ArrayList();
        for (Libro libro : lista) {
            String isbnLista = String.valueOf(libro.getIsbn());
            String isbnFiltrado = String.valueOf(isbn);
            if (isbnLista.contains(isbnFiltrado)) {
                listaFiltrada.add(libro);
            }
        }
        return listaFiltrada;
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileWriter getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileWriter modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    public Scanner getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(Scanner modoLectura) {
        this.modoLectura = modoLectura;
    }

}
