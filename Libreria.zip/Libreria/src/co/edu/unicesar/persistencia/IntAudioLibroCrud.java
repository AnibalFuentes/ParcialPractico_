package co.edu.unicesar.persistencia;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.AudioLibro;
import java.util.List;


public interface IntAudioLibroCrud {

    void registrar(AudioLibro l) throws ExcepcionArchivos;

    List<AudioLibro> leer() throws ExcepcionArchivos;

    AudioLibro buscar(AudioLibro l) throws ExcepcionArchivos;

    AudioLibro eliminar(AudioLibro l) throws ExcepcionArchivos;

    List<AudioLibro> filtrar(int isbn) throws ExcepcionArchivos;
}
