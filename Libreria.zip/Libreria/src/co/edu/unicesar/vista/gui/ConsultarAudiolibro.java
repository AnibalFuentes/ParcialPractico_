package co.edu.unicesar.vista.gui;


import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.AudioLibro;
import co.edu.unicesar.modelo.ListAudiolibrosCrud;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public final class ConsultarAudiolibro extends JDialog {

    private JPanel panelBusqueda, panelPrinicipal, panelOpciones;
    private JScrollPane panelTabla;
    private JLabel lbBuqueda;
    private JButton btnEliminar;
    private JTextField txtBusqueda;
    private JTable tablaRegistros;
    private DefaultTableModel modeloTabla;
    private String titulosTabla[] = {"ISBN", "TITULO", "AUTOR", "AÑO", "COSTO", "DURACIÓN", "PESO", "FORMATO"};
    private String datosTabla[][] = {null};
    private Container contenedor;
    private ListAudiolibrosCrud modelo;

    public ConsultarAudiolibro(Frame frame, boolean bln) {
        super(frame, bln);
        this.modelo = new ListAudiolibrosCrud();
        this.setTitle("CATALOGO DE AUDIOLIBROS");
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.iniciarComponentes();
        this.setSize(500, 600);
        //this.pack();
        try {
            List<AudioLibro> lista = this.modelo.leer();
            this.actualizarTabla(lista);
        } catch (ExcepcionArchivos e) {
        }
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void iniciarComponentes() {
        this.contenedor = this.getContentPane();
        this.contenedor.setLayout(new FlowLayout());
        this.panelPrinicipal = new JPanel();
        this.panelPrinicipal.setLayout(new BorderLayout());
        this.iniciarPanelBusqueda();
        this.iniciarPanelTabla();
        this.iniciarPanelOpciones();
        this.panelPrinicipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.contenedor.add(this.panelPrinicipal);
    }

    private void iniciarPanelBusqueda() {
        this.panelBusqueda = new JPanel();
        this.panelBusqueda.setLayout(new FlowLayout(FlowLayout.CENTER));
        this.lbBuqueda = new JLabel("N° ISBN: ");
        this.txtBusqueda = new JTextField(15);
        this.txtBusqueda.addKeyListener(new eventoFiltroBusqueda());
        this.panelBusqueda.add(this.lbBuqueda);
        this.panelBusqueda.add(this.txtBusqueda);
        this.panelBusqueda.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.panelPrinicipal.add(this.panelBusqueda, BorderLayout.NORTH);

    }

    private void iniciarPanelTabla() {
        this.tablaRegistros = new JTable();
        this.modeloTabla = new DefaultTableModel(this.datosTabla, this.titulosTabla);
        this.tablaRegistros.setModel(this.modeloTabla);
        this.panelTabla = new JScrollPane(this.tablaRegistros);
        this.panelPrinicipal.add(this.panelTabla, BorderLayout.CENTER);
    }

    private void iniciarPanelOpciones() {
        this.panelOpciones = new JPanel();
        this.panelOpciones.setLayout(new FlowLayout(FlowLayout.RIGHT));
        this.btnEliminar = new JButton("ELIMINAR AUDIOLIBRO");
        this.btnEliminar.addActionListener(new eventoClickEliminar());
        this.panelOpciones.add(this.btnEliminar);
        this.panelOpciones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        this.panelPrinicipal.add(this.panelOpciones, BorderLayout.SOUTH);
    }

    public void actualizarTabla(List<AudioLibro> lista) {
        this.modeloTabla.setNumRows(0);
        for (AudioLibro l : lista) {
            String datos[] = {String.valueOf(l.getIsbn()), l.getTitulo(), l.getAutor(), String.valueOf(l.getAnio()), String.valueOf(l.getCosto()), String.valueOf(l.getDuracion()), String.valueOf(l.getPeso()), String.valueOf(l.getFormato())};
            this.modeloTabla.addRow(datos);
        }
    }

    private void filtrarDatos() {
        try {
            int isbn;
            List<AudioLibro> lista;
            if (this.txtBusqueda.getText().isEmpty()) {
                isbn = 0;
                lista = this.modelo.leer();
            } else {
                isbn = Integer.valueOf(this.txtBusqueda.getText());
                lista = this.modelo.filtrar(isbn);
            }
            this.actualizarTabla(lista);
        } catch (ExcepcionArchivos e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    private void eliminarDato() {
        int row = this.tablaRegistros.getSelectedRow();
        String isbnEliminado = (String) this.modeloTabla.getValueAt(row, 0);
        try {
            AudioLibro eliminado = this.modelo.eliminar(new AudioLibro(String.valueOf(isbnEliminado)));
            Icon elim;
            elim = new ImageIcon("src\\co\\edu\\unicesar\\vista\\gui\\imagenes\\cancelar.png");
            this.filtrarDatos();
            JOptionPane.showMessageDialog(null, "AUDIOLIBRO ELIMINADO CORRECTAMENTE", " ATENCIÓN", JOptionPane.WARNING_MESSAGE, elim);
        } catch (ExcepcionArchivos e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    class eventoFiltroBusqueda implements KeyListener {
        @Override
        public void keyTyped(KeyEvent e) {
            int key = e.getKeyChar();
            boolean numeros = key >= 48 && key <= 57; //Rango de letras MAYUSCULAS en ASCII
            boolean retroceso = key == 8; //Retroceso en ASCII
            boolean enter = key == 13; //Enter en ASCII
            if (!(numeros || retroceso || enter)) {
                JOptionPane.showMessageDialog(null, "SOLO SE PERMITE EL INGRERSO DE NÚMEROS.");
                e.consume();
            }
        }

        @Override
        public void keyPressed(KeyEvent e) {
            filtrarDatos();

        }

        @Override
        public void keyReleased(KeyEvent e) {
            filtrarDatos();
        }
    }

    class eventoClickEliminar implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            eliminarDato();
        }
    }
}
