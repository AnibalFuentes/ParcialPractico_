
package co.edu.unicesar.vista.gui;


public class Principal {
    public static void main(String[] args) {
        MenuPrincipal guiMenuPrincipal = new MenuPrincipal();
        guiMenuPrincipal.setVisible(true);
    }
}
