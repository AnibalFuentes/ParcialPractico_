/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package co.edu.unicesar.vista.gui;

import co.edu.unicesar.excepciones.ExcepcionArchivos;
import co.edu.unicesar.modelo.Libro;
import co.edu.unicesar.modelo.ListLibrosCrud;
import javax.swing.JOptionPane;

/**
 *
 * @author ANIBAL FUENTES
 */
public class RegistrarLibro extends javax.swing.JDialog {

    private ListLibrosCrud modelo;
    public RegistrarLibro(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        this.modelo = new ListLibrosCrud();
    }

    void limpiar() {
        in_isbn.setText("");
        in_titulo.setText("");
        in_autor.setText("");
        in_año.setText("");
        in_costo.setText("");
        in_paginas.setText("");
        in_edicion.setText("");
    }

    private Libro leer() {
        //ISBN
        String isbn = this.in_isbn.getText();
        if (isbn.isEmpty()) {
            this.in_isbn.grabFocus();
            JOptionPane.showMessageDialog(null, "Registre el ISBN", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("Registre el ISBN");
        }
        if (isbn.equals(0)) {
            this.in_isbn.grabFocus();
            JOptionPane.showMessageDialog(null, "El ISBN no puede ser menor o igual a 0", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("El ISBN no puede ser menor o igual a 0");
        }
        //TITULO
        String titulo = this.in_titulo.getText();
        if (titulo.isEmpty()) {
            this.in_titulo.grabFocus();
            JOptionPane.showMessageDialog(null, "Registre el TITULO", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("Registre el TITULO");
        }
        //AUTOR
        String autor = this.in_autor.getText();
        if (autor.isEmpty()) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "Registre el AUTOR", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("Registre el AUTOR");
        }
        //AÑO
        int anio = Integer.valueOf(this.in_año.getText());
        if (in_año.getText().isEmpty()) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "Registre el AÑO", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("Registre el AÑO");
        }
        if (anio <= 0) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "El AÑO no puede ser menor o igual a 0", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("El AÑO no puede ser menor o igual a 0");
        }
        //COSTO
        double costo = Double.valueOf(this.in_costo.getText());
        if (in_año.getText().isEmpty()) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "Registre el COSTO", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("Registre el AUTOR");
        }
        if (costo <= 0) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "El COSTO no puede ser menor o igual a 0", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("El COSTO no puede ser menor o igual a 0");
        }
        //PAGINAS
        int paginas = Integer.valueOf(this.in_paginas.getText());
        if (in_paginas.getText().isEmpty()) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "Registre el N° de PAGINAS", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException(" Registre el N° de PAGINAS");
        }
        if (paginas <= 0) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "El N° de PAGINAS no puede ser menor o igual a 0", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("El N° de PAGINAS no puede ser menor o igual a 0");
        }
        //EDICION
        int edicion = Integer.valueOf(this.in_edicion.getText());
        if (in_paginas.getText().isEmpty()) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "Registre el N° de EDICIÓN", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("Registre el N° de EDICIÓN");
        }
        if (edicion <= 0) {
            this.in_autor.grabFocus();
            JOptionPane.showMessageDialog(null, "El N° de EDICIÓN no puede ser menor o igual a 0", "¡ERROR!", JOptionPane.ERROR_MESSAGE);
            throw new NullPointerException("El N° de EDICIÓN no puede ser menor o igual a 0");
        }
        return new Libro(paginas, edicion, isbn, titulo, autor, anio, costo);
    }

    private void registrar() {
        try {
            Libro libro = this.leer();
            this.modelo.registrar(libro);
            limpiar();
            JOptionPane.showMessageDialog(null, "LIBRO REGISTRADO ");
            System.out.println("LIBRO REGISTRADO: " + libro.obtenerDatosString());
        } catch (ExcepcionArchivos e) {
            JOptionPane.showMessageDialog(this, "Error", e.getMessage(), JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        in_autor = new javax.swing.JTextField();
        in_titulo = new javax.swing.JTextField();
        in_isbn = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        limpiar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        registar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        in_paginas = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        in_edicion = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        in_costo = new javax.swing.JTextField();
        in_año = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        in_autor.setBackground(new java.awt.Color(255, 255, 255));
        in_autor.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        in_autor.setForeground(new java.awt.Color(18, 18, 18));
        in_autor.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        in_autor.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        in_titulo.setBackground(new java.awt.Color(255, 255, 255));
        in_titulo.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        in_titulo.setForeground(new java.awt.Color(18, 18, 18));
        in_titulo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        in_titulo.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        in_isbn.setBackground(new java.awt.Color(255, 255, 255));
        in_isbn.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        in_isbn.setForeground(new java.awt.Color(18, 18, 18));
        in_isbn.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        in_isbn.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/co/edu/unicesar/vista/gui/imagenes/book-add-icon (1).png"))); // NOI18N
        jLabel1.setText("LIBRO");

        limpiar.setBackground(new java.awt.Color(0, 0, 102));
        limpiar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        limpiar.setForeground(new java.awt.Color(255, 255, 255));
        limpiar.setText("Limpiar");
        limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(18, 18, 18));
        jLabel2.setText("ISBN:");

        registar.setBackground(new java.awt.Color(0, 0, 102));
        registar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        registar.setForeground(new java.awt.Color(255, 255, 255));
        registar.setText("Registar");
        registar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(18, 18, 18));
        jLabel3.setText("TITULO:");

        jLabel8.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(18, 18, 18));
        jLabel8.setText("N° PÁGINAS:");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(18, 18, 18));
        jLabel4.setText("AUTOR:");

        in_paginas.setBackground(new java.awt.Color(255, 255, 255));
        in_paginas.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        in_paginas.setForeground(new java.awt.Color(18, 18, 18));
        in_paginas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        in_paginas.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(18, 18, 18));
        jLabel5.setText("AÑO:");

        in_edicion.setBackground(new java.awt.Color(255, 255, 255));
        in_edicion.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        in_edicion.setForeground(new java.awt.Color(18, 18, 18));
        in_edicion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        in_edicion.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(18, 18, 18));
        jLabel6.setText("COSTO:");

        jLabel9.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(18, 18, 18));
        jLabel9.setText("N°EDICIÓN:");

        in_costo.setBackground(new java.awt.Color(255, 255, 255));
        in_costo.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        in_costo.setForeground(new java.awt.Color(18, 18, 18));
        in_costo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        in_costo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        in_costo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                in_costoActionPerformed(evt);
            }
        });

        in_año.setBackground(new java.awt.Color(255, 255, 255));
        in_año.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        in_año.setForeground(new java.awt.Color(18, 18, 18));
        in_año.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        in_año.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        in_año.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                in_añoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(limpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(registar, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(in_costo)
                    .addComponent(in_paginas)
                    .addComponent(in_edicion)
                    .addComponent(in_año)
                    .addComponent(in_autor)
                    .addComponent(in_titulo)
                    .addComponent(in_isbn, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(137, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in_isbn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in_titulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in_autor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in_año, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in_costo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in_paginas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(in_edicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(registar, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                    .addComponent(limpiar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarActionPerformed
        limpiar();
    }//GEN-LAST:event_limpiarActionPerformed

    private void registarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registarActionPerformed

        registrar();
    }//GEN-LAST:event_registarActionPerformed

    private void in_costoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_in_costoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_in_costoActionPerformed

    private void in_añoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_in_añoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_in_añoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistrarLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistrarLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistrarLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistrarLibro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                RegistrarLibro dialog = new RegistrarLibro(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField in_autor;
    private javax.swing.JTextField in_año;
    private javax.swing.JTextField in_costo;
    private javax.swing.JTextField in_edicion;
    private javax.swing.JTextField in_isbn;
    private javax.swing.JTextField in_paginas;
    private javax.swing.JTextField in_titulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton limpiar;
    private javax.swing.JButton registar;
    // End of variables declaration//GEN-END:variables
}
